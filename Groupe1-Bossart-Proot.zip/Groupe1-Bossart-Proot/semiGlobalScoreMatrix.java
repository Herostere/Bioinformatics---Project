public record semiGlobalScoreMatrix(int score, int[][] matrix, int index, byte position) {

}
